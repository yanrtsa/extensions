
	KeiyoushiKEI@2c295db5fef9d46aded5a09b0a6d80d18b5b7612a37313975f6b39712ad6c5e2"<
https://keiyoushi.github.iohttps://discord.gg/3FbCpdKbdY��
�
Manga Livre+eu.kanade.tachiyomi.extension.pt.mangalivre�
lhttps://raw.githubusercontent.com/yanrtsa/extensions/refs/heads/repo/apk/tachiyomi-pt.mangalivre-v1.4.69.apkyhttps://raw.githubusercontent.com/yanrtsa/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mangalivre.png"1.4(E21.4.69B5ؕ�܁��'Manga Livrept-BR"https://toonlivre.net